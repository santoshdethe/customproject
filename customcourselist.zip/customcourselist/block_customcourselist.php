<?php // This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Custom course list block
 *
 * @package    block_customcourselist
 * @copyright  1999 onwards Martin Dougiamas (http://dougiamas.com)
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

class block_customcourselist extends block_base {
    public function init() {
        $this->title = get_string('customcourselist', 'block_customcourselist');
    }
	function get_content() {
        global $CFG, $USER, $DB, $OUTPUT;
		require_once("{$CFG->libdir}/completionlib.php");
		$result = $DB->get_records_sql('select id,idnumber,fullname,completionnotify,DATE_FORMAT(FROM_UNIXTIME(timecreated), "%d-%m-%Y") as date_created from {course} where id!=1');
		$this->content = new stdClass;
        $this->content->text = '';
		
	    $course = new stdClass;
	    
		$this->content->text .= '<div class="new">';
		foreach($result as $key => $record){
			$course->id = $record->id;
			$cinfo = new completion_info($course);
			$iscomplete = $cinfo->is_course_complete($USER->id);
			if($iscomplete){
				$status = 'Completed';
				$this->content->text .= '<p>'.$record->idnumber.'<a href="'.$CFG->wwwroot.'/course/view.php?id='.$record->id.'"> - ' .$record->fullname.'</a> - '.$record->date_created.' - '.$status.'</p>';
			} else {
			    $this->content->text .= '<p>'.$record->idnumber.'<a href="'.$CFG->wwwroot.'/course/view.php?id='.$record->id.'"> - ' .$record->fullname.'</a> - '.$record->date_created.'</p>';
			}
		}
	    
		
       return $this->content;
    }
	
}